import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

import javax.swing.*;


public class Score extends JFrame implements ActionListener {

    
    Score(String name,int Score){
        getContentPane().setBackground(Color.WHITE);
        setBounds(50,0,1200,800);
        
        setLayout(null);
    
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("imgscore.jpg"));
        Image i2= i1.getImage().getScaledInstance(300,250,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
    
        image.setBounds(10,100,400,350);
        add(image);
        
        JLabel heading=new JLabel("Thank you "+ name +" for playing simple minds.");
        heading.setBounds(60,50,700,30);
        heading.setFont(new Font("Tahoma",Font.BOLD,28));
        add(heading);
        setVisible(true);
         JLabel lbscore=new JLabel("Your score is  "+ Score);
        lbscore.setBounds(550,220,400,40);
        lbscore.setFont(new Font("Tahoma",Font.BOLD,40));
        add(lbscore);

        
        JButton submit =new JButton("Play Again");
        submit.setBounds(590,290,190,60);
         submit.setFont(new Font("Tahoma",Font.BOLD,25));
       
        submit.setBackground(new Color(30,144,254));
        submit.setForeground(Color.WHITE);
        
        add(submit);
        submit.addActionListener(this);
        setVisible(true);


    }
    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Login();

     }
    public static void main(String[] args) {
        new Score("user",0);
    }
    
}
